=========================================================
 CHAMA CHETU — Community Savings & Merry-Go-Round Manager
 LIVE DEPLOYMENT PACKAGE — Option A: Netlify Drop
 Packaged: 6 November 2026 (v3)
=========================================================

WHAT IS IN THIS FOLDER
  index.html                    The complete working app (drag THIS folder to Netlify)
  CSLM-Deployment-Guide.pdf     Full step-by-step deployment guide
  CSLM-Deployment-Guide.docx    Same guide, editable Word version
  README.txt                    This file

DEPLOY IN 3 MINUTES (Option A — Netlify Drop)
  1. Unzip this package (if you have not already).
  2. Go to  https://app.netlify.com/drop  in your browser.
  3. Drag THIS ENTIRE FOLDER (or this zip file) onto the page.
  4. Netlify gives a live URL instantly, e.g. https://random-name-1234.netlify.app
  5. Sign up free and CLAIM the site so it never expires.
  6. Site configuration > Change site name > e.g. "chama-chetu"
     -> permanent link becomes https://chama-chetu.netlify.app
  7. (Optional) Domains > Add a domain for a branded URL; HTTPS is automatic.

GO-LIVE CHECKLIST (before real group use)
  [ ] 1. Open the live URL; confirm the CHAMA CHETU login screen shows.
  [ ] 2. FRESH START: on the official device, clear the site data once
         (browser > site settings > Clear & reset) to remove the demo group.
  [ ] 3. Sign in as admin / Admin@123 -> Settings:
         - group name, registration no, contact
         - MONTHLY contribution amount AND Merry-go-round contribution
         - absence / late-arrival / apology fines
         - DELAYED-PAYMENT fine (auto-fined at meeting close)
  [ ] 4. Merry-Go-Round screen: set per-member amount and rotation order.
  [ ] 5. Share-Out screen: set amount per member and share date.
  [ ] 6. CHANGE ALL DEMO PINs (admin/chair/secretary/treasurer/member).
  [ ] 7. Register members one by one, or Members > "Import Excel" using the
         downloadable template (columns: Full Name, Phone, Gender, ID No,
         Village, Next of Kin, Remarks).
  [ ] 8. Assign roles: Settings > Users & roles > Set (admin only, audited).
  [ ] 9. AFTER EVERY MEETING: Audit > "Download full backup (JSON)".
  [ ] 10. Add to Home screen on every phone (works fully offline).

DEMO ACCOUNTS (change PINs before production)
  admin / Admin@123 - Administrator | chair / Chair@123 - Chairperson
  secretary / Sec@123 - Secretary   | treasurer / Treas@123 - Treasurer
  member / Member@123 - Ordinary member (own records only)

WHAT CHANGED IN v3 (CHAMA CHETU)
  1. Admin can EDIT and REMOVE members (removal keeps full history, audited).
  2. Admin assigns roles to other users in Settings (audited; last admin
     cannot be demoted; admin can also add new users).
  3. Monthly savings AND merry-go-round contributions are recorded on ONE
     combined page (Payments screen and inside each meeting workspace).
  4. Members list can be uploaded from Excel (.xlsx/.xls/.csv) with a guided,
     downloadable template, live preview, and duplicate/blank-row skipping.
     Excel reading is bundled INSIDE the app - no internet needed.
  5. Configurable fine for DELAYED PAYMENT - applied automatically when a
     meeting is closed to any member who paid less than the monthly amount.
  6. Delayed merry-go-round is tracked per member (the old loan-interest
     concept is gone).
  7. A delayed merry-go-round member records a DOUBLE penalty (2x the owed
     MGR amount) - the old auto principal/interest split is gone.
  8. The SPINNING WHEEL now selects the next MERRY-GO-ROUND BENEFICIARY
     (not a loan beneficiary) - genuine CSPRNG, fully audited, no repeat
     winner within a cycle, and the spun member becomes the next payout.
  9. All loan features have been REMOVED engine-wide (verified: zero
     loan/interest code remains).
  10. Share-Out module: configure an amount per member and a date, preview
      recipients and totals, then execute - reduces each member's savings
      and the group cash, fully audited, with its own report.

SUPPORT NOTES
  - Works fully OFFLINE; data lives on each device's browser storage
    (key: chama_chetu_db). Backups from the earlier Community Savings &
    Lending Manager build still restore (key migration is built in).
  - Never put passwords or M-Pesa keys inside index.html - client files are
    public. Server credentials belong in environment variables only.
